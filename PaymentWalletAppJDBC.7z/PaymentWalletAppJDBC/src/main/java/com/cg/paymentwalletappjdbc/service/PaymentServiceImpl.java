package com.cg.paymentwalletappjdbc.service;

import java.util.ArrayList;
import com.cg.paymentwalletappjdbc.dao.IPaymentDao;
import com.cg.paymentwalletappjdbc.dao.PaymentDaoImpl;
import com.cg.paymentwalletappjdbc.dto.Wallet;
import com.cg.paymentwalletappjdbc.exception.IPaymentException;
import com.cg.paymentwalletappjdbc.exception.PaymentException;

public class PaymentServiceImpl implements IPaymentService{
	IPaymentDao dao = new PaymentDaoImpl();

	public int createAccount(Wallet wallet) throws PaymentException {
		int row;
		row = dao.createAccount(wallet);
		return row;
	}

	public double showBalance(String userId) {
		return dao.showBalance(userId);
	}

	public boolean deposit(String userId, double amount) {
		boolean result = false;
		if (amount > 0) {
			dao.deposit(userId, amount);
			result = true;
		}

		return result;	}

	public boolean withdraw(String userId, double amount) {
		boolean result = false;
		if (dao.showBalance(userId) >= amount) {
			dao.withdraw(userId, amount);
			result = true;
		}

		return result;
	}

	public boolean fundTransfer(String userIdSender, String userIdReceiver, double amount) throws PaymentException {
		boolean result = false;
		if (dao.showBalance(userIdSender) >= amount) {
			if (dao.fundTransfer(userIdSender, userIdReceiver, amount)) {
				result = true;
			}

		}

		return result;
	
	}

	public boolean validateDetails(Wallet wallet) throws PaymentException {
		boolean result = true;
		String regex = "[A-Z]{1}[a-z]+";
		String regex2 = "[0-9]{10}";
		String regex3 = "[a-z0-9_.]{1,}@[a-z]{1,10}.com";
		String regex4 = "[A-Za-z0-9]{4,}";
		if (wallet.getName().matches(regex)) {

			if (wallet.getPhNumber().matches(regex2)) {

				if (wallet.getEmailId().matches(regex3)) {

					if (!(wallet.getUserId().equals(wallet.getPassword()))) {

						if (wallet.getUserId().matches(regex4)) {

							if (wallet.getPassword().length() >= 8) {

								result = true;

							} else
								throw new PaymentException(IPaymentException.ERROR9);

						} else
							throw new PaymentException(IPaymentException.ERROR8);

					} else
						throw new PaymentException(IPaymentException.ERROR7);

				} else
					throw new PaymentException(IPaymentException.ERROR3);

			} else
				throw new PaymentException(IPaymentException.ERROR2);

		} else
			throw new PaymentException(IPaymentException.ERROR1);
		return result;
	}

	public String login(String id, String password) throws PaymentException {
		if (dao.login(id, password) != null) {
			return dao.login(id, password);
		} else
			throw new PaymentException(IPaymentException.ERROR5);

	}

	public ArrayList<String> printTransaction(String userId) {
		ArrayList<String> list = dao.printTransactions(userId);
		return list;
	}

	

}
