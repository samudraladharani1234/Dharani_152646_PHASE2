package com.cg.paymentwalletappjdbc.service;

import java.util.ArrayList;

import com.cg.paymentwalletappjdbc.dto.Wallet;
import com.cg.paymentwalletappjdbc.exception.PaymentException;

public interface IPaymentService {
	public int createAccount(Wallet wallet) throws PaymentException;

	public double showBalance(String phNumber);

	public boolean deposit(String phNumber, double amount);

	public boolean withdraw(String phNumber, double amount);

	public boolean fundTransfer(String phSender, String phReceiver, double amount) throws PaymentException;

	public boolean validateDetails(Wallet wallet) throws PaymentException;

	public String login(String id, String password) throws PaymentException;

	public ArrayList<String> printTransaction(String userId);

}
