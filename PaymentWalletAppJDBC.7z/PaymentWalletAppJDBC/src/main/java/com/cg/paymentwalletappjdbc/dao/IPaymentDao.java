package com.cg.paymentwalletappjdbc.dao;

import java.util.ArrayList;

import com.cg.paymentwalletappjdbc.dto.Wallet;
import com.cg.paymentwalletappjdbc.exception.PaymentException;

public interface IPaymentDao {
	public int createAccount(Wallet wallet) throws PaymentException;

	public double showBalance(String userId);

	public void deposit(String userId, double amount);

	public void withdraw(String userId, double amount);

	public boolean fundTransfer(String userIdSender, String userIdReceiver, double amount) throws PaymentException;

	public ArrayList<String> printTransactions(String userId);

	public String login(String id, String password) throws PaymentException;

}
