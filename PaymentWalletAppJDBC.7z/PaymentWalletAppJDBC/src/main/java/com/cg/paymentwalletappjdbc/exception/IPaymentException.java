package com.cg.paymentwalletappjdbc.exception;

public interface IPaymentException {
	String ERROR1="Name Should Start With Capital Letter ";
	String ERROR2="Invalid Phone Number";
	String ERROR3="Invalid Email Id";
	String ERROR4="Account already exists";
	String ERROR5="Invalid UserId or Password ";
	String ERROR6="Couldnot Transfer Amount !";
	String ERROR7="Username and Password should not be Same";
	String ERROR8="Username should contain Atleast 4 Characters";
	String ERROR9="Password should be longer than 8 Characters";


}
